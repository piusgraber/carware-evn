<script>
  import { getData } from "./db.js";
  import { location, querystring } from "svelte-spa-router";
  import { dateDisp, timDisp, options } from "./helpers/time.js";
  import Evn from "./Evn.svelte";
  import { push } from "svelte-spa-router";
  import { texte } from "./helpers/texte.js";
  import { styles } from "./stores/css_store.js";

  $: cssVarStyles = `
   --lp-bg-color:${$styles.lpBgColor};
   --proof-bg-color:${$styles.proofBgColor};
   --proof-color:${$styles.proofColor};
   --input-invalid-bg-color:${$styles.inputInvalidBgColor};
   --input-invalid-color:${$styles.inputInvalidColor};
   `;



// CSS Variablen
  // Standard Werte
  $: brandSrc = $styles.brandSrc;
  $: brandWidth = $styles.brandWidth;


const css = 
{
  GCS_AUTOKUNZ : {
    modeImage: 'prooftransp',
    brandSrc: 'kunz.png',
    brandWidth: '380',
    brandSrc2: 'transp.png',
    lpBgColor: '#e7e6e6',
    proofBgColor: '#000000',
    proofColor: '#eeeeee',
  inputInvalidBgColor: '#E21223',
  inputInvalidColor: '#ffffff'
  },
  'BME' : {
    modeImage: 'prooftransp',
    brandSrc: 'transp.png', //'BME.png',
    brandWidth: '200',
    brandSrc2: 'transp.png',
    lpBgColor: '#e7e6e6',
    proofBgColor: '#a1a1a2',
    proofColor: '#444444',
    inputInvalidBgColor: '#06AF8F',
    inputInvalidColor: '#333333'
  },
  'ALR' : {
    modeImage: 'proof',
    brandSrc: 'transp.png',
    brandWidth: '200',
    brandSrc2: "LogoALR.png",
    lpBgColor: '#e7e6e6',
    proofBgColor: 'rgb(145, 145, 145)',
    inputInvalidBgColor: '#ce232a',
    inputInvalidColor: '#ffffff'
  },
  'SWILOG' : {
    modeImage: 'proof',
    brandSrc: 'carware.png',
    brandWidth: '345',
    brandSrc2: 'carwareswsm.png',
    lpBgColor: '#e7e6e6',
    lpBgColor: '#e7e6e6',
    proofBgColor: 'rgb(145, 145, 145)',
    inputInvalidBgColor: '#06AF8F',
    inputInvalidColor: '#ffffff'
  },
  GCS_1234 : {
    modeImage: 'prooftransp',
    brandSrc: 'kunz.png',
    brandWidth: '100',
    brandSrc2: 'transp.png',
    lpBgColor: '#e7e6e6',
    proofBgColor: '#000000',
    proofColor: '#eeeeee',
    inputInvalidBgColor: '#E21223',
  inputInvalidColor: '#ffffff'
},
  vonRotz: {
    modeImage: 'proof',
    brandSrc: "vonRotzTop.png",
    brandWidth: '200',
    brandSrc2: "vonRotzBottom.png",
    lpBgColor: '#e7e6e6',
    proofBgColor: 'rgb(145, 145, 145)',
    inputInvalidBgColor: '#06AF8F',
    inputInvalidColor: '#ffffff'
  },
  default: {
    modeImage: 'proof',
    brandSrc: "i-logo.png",
    brandWidth: '50',
    brandSrc2: "auto-i-logo.png",
    lpBgColor: '#e7e6e6',
    proofBgColor: 'rgb(145, 145, 145)',
    inputInvalidBgColor: '#06AF8F',
    inputInvalidColor: '#ffffff'
}
}

const getTemplate = (swkey, garageid) => {
  let tag = swkey + '_' + garageid;
  if (swkey=='ALR') {
    tag = swkey;
  }
  if (swkey=='BME') {
    tag = swkey;
  }
  if (swkey=='VONROTZ') {
    tag = 'vonRotz';
  }
  if (swkey=='SWILOG') {
    tag = swkey;
  }
  if (!css[tag]) {
    tag = 'default';
  }
  if (css[tag]) {
    $styles.modeImage = css[tag].modeImage;
    $styles.brandSrc = css[tag].brandSrc;
    $styles.brandWidth = css[tag].brandWidth;
    $styles.brandSrc2 = css[tag].brandSrc2;
    $styles.lpBgColor = css[tag].lpBgColor;
    $styles.proofBgColor = css[tag].proofBgColor;
    $styles.proofColor = css[tag].proofColor;
//    $styles.btnBgColor = css[tag].btnBgColor;
//    $styles.btnDisabledBgColor = css[tag].btnDisabledBgColor;
    $styles.inputInvalidBgColor = css[tag].inputInvalidBgColor;
    $styles.inputInvalidColor = css[tag].inputInvalidColor;
  } else {

  }
};

  let data = {};
  let rawLead = {};
  //  getData({entity: 'plzOrt', params: {plz:6010, kanton:'lu'}})

  const goto = (where) => {
    push("" + where + "?" + $querystring);
  };
  let alreadyDone = false;
  let evnAlreadyDone = false;
  let mailAlreadyDone = false;
  let tlang ='de';
  // Lead-Daten aus DB holen
  const getRaw = async (guid, clr) => {
    rawLead = {kontakt: {}};
    sent = false;
    alreadyDone = false;
    evnAlreadyDone = false;
    mailAlreadyDone = false;
    textSent = '';
    try {
      let res = await fetch("https://api.car-ware.ch/rawGuid?guid=" + guid + "");
      let dt =await res.json();
      if (dt.length) {
        rawLead = dt[0];
        getTemplate(rawLead.agent, rawLead.garage_idkey)
        console.log(JSON.stringify(rawLead))
        if (rawLead.trans && rawLead.trans.length > 4) {
          // whitelabel, offer oder compare
          mailAlreadyDone = true;
        }
        if (evnSent || rawLead.evnsent) {
          // evn bereits angefordert
          evnAlreadyDone = true;
        }
        rawLead.wsmarketyp = rawLead.ws ? rawLead.wsmarketyp : '';
        rawLead.wsmarketyp = rawLead.wsmarketyp ? rawLead.wsmarketyp : '';
         if (!rawLead.preiszubehoer) {
          rawLead.preiszubehoer = parseInt( rawLead.katalogpreis / 10);
        }
        rawLead.bemerkungen = rawLead.bemerkungen ? rawLead.bemerkungen : '';
        lang = rawLead.garage_spracheid==3 ? "I" : rawLead.garage_spracheid==2 ? "F" : "D";
        tlang = (lang == 'I' ? 'it'  : lang == 'F' ? 'fr'  : 'de'); 
        if (!rawLead.kanton) rawLead.kanton = "";
        if (!rawLead.ivgrund) rawLead.ivgrund = "";
        if (!rawLead.nationalitaet) rawLead.nationalitaet = "";

          
        rawLead.geburtstag = rawLead.geburtstag  ? rawLead.geburtstag.substring(0, 10) : null;
        rawLead.invsetz = rawLead.invsetz  ? rawLead.invsetz.substring(0, 10) : null;
        rawLead.vnab = rawLead.vnab  ? rawLead.vnab.substring(0, 10) : null;
        rawLead.user_telefon = rawLead.user_telefon ? rawLead.user_telefon : '';

        // Halter und Standort
        let halter = {}
        let standort = {}
        if (rawLead.agent=='VONROTZ') {
            halter.anredeid = rawLead.halteranredeid;
            halter.name = rawLead.haltername;
            halter.adresse = rawLead.halteradresse;
            halter.plz = rawLead.halterplz;
            halter.ort = rawLead.halterort;
            standort.anredeid = rawLead.standortanredeid;
            standort.name = rawLead.standortname;
            standort.adresse = rawLead.standortadresse;
            standort.plz = rawLead.standortplz;
            standort.ort = rawLead.standortort;
            rawLead.halter = halter;
            rawLead.standort = standort;
        } else {
          rawLead.halter = {anredeid: 0, name: '', adresse: '', plz: '', ort: ''};          
          if (rawLead.plz) {
            rawLead.halter.anredeid = rawLead.anredeid ? rawLead.anredeid : '';
            if (rawLead.isfirma) {
              rawLead.halter.name = rawLead.firmaname;
            } else {
              rawLead.halter.name = rawLead.vorname + ' ' + rawLead.nachname;
            }
            rawLead.halter.adresse = rawLead.strasse + ' ' +  rawLead.hausnummer;
            rawLead.halter.plz = rawLead.plz
            rawLead.halter.ort = rawLead.ort;
          }
          rawLead.standort = standort;
        }
        if (rawLead.ws == null) rawLead.ws = '';
        if (rawLead.leasing == null) rawLead.leasing = '';
        if (clr) {
          rawLead.evnsent = null;
        }
        if (rawLead.evnsent) {
          alreadyDone = true;
        }
      } else {
      }
    } catch (err) {
      alert(err); // Failed to fetch
    }
  };

  $: title =
    image == "compare"
      ? lang=='F' ? "Comparatif d'assurances" :
      lang=='I' ? "Confronto assicurativo" : "Versicherungsvergleich"
      : image == "offer"
      ? 
      lang=='F' ? "Offre d'assurance" : lang=='I' ? "Offerta assicurativa" : "Versicherungsofferte"
      : texte.best[tlang];
  $: image = $location.substring(1, $location.length);
  $: modeImage = image=='proof' ? $styles.modeImage : image; 

  $: {
    if ($querystring || image) {
      getRaw($querystring, false);
    }
  }
  let lang = "D";
  let page = '';
  $: {
    if (lang) {
      if (image) {
        page = '/' + image;
        goto(page);
      }
    }
  }

  const checkEmailValid = (email) => {

 if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
  {
    return (true)
  }
//    alert("You have entered an invalid email address!")
    return (false)
   };

    $:
        emailValid = checkEmailValid(rawLead.email);
    
let textSent = '';
const sendLanding = async() => {
  textSent = texte.emailSending[tlang];
  sent = true;
        try {
            let d = await fetch(
              "https://api.car-ware.ch/createLead?gid=" +
//              "http://127.0.0.1:3344/createLead?gid='" +
                    rawLead.guid +
                    "&vo=" +
                    image + 
                    "&email=" +
                    rawLead.email + 
                    ""
            );
            let p = d.json();
            p.then((d) => {
              data = d;
              textSent = texte.emailSent[tlang];
            }
              );
        } catch (err) {
            alert(err); // Failed to fetch
        }
  
}

let sent = false;
let evnSent = false;

let redoEvn = false;
const redo = () => {
  getRaw($querystring, true)
  .then ((dt) => {
    rawLead.evnsent = null;
    evnSent = false;
    redoEvn = true;
  });
//  getRaw(rawLead.guid);
}


$: if (evnSent) {
  getRaw($querystring, false);
}

let showInfo = false;
const doShowInfo = () => {
  showInfo=true
}

// für BME keine Mails Offerte/Vergleich versenden
 $: demo = rawLead && rawLead.agent && (rawLead.agent.toUpperCase()=='BME');
//$: demo = false;

</script>

<body  class=evnbody>






  <div class:grid={image != "proof"} class:gridevn={image == "proof"}>
    <!-- Header -->
    <div
      class:offer={image == "offer"}
      class:compare={image == "compare"}
      class:proof={image == "proof"}
      class="row1"
    >
      <table>
        <tr>
          <td style="width: 150px; vertical-align: middle">
            <img src="images/{modeImage}.png" alt={modeImage} />
          </td>
          <td style="font-size: 24pt; width: 1100px; vertical-align: middle"
            ><b><u>{title}:</u></b>
          </td>
{#if image=="proof"}          
<td style="font-size: 16pt; width: {brandWidth}px; vertical-align: middle">
  {#if rawLead && rawLead.agent=='VONROTZ'}
  <img style="height: 100px" src="images/{brandSrc}" alt="{brandSrc}"/>
  {:else}
  <img style="height: 50px" src="images/{brandSrc}" alt="{brandSrc}"/>
  {/if}
</td>
{:else}
<td style="font-size: 16pt; width: 520px; vertical-align: middle;">
  <b>{lang=='F' ? "Un service gratuit de CARWARE AG" : lang=='I' ? "Un servizio gratuito di CARWARE AG" : "Ein kostenloser Service der CARWARE AG"}</b>
</td>
  
{/if}
            <td style="font-size: 16pt; width: 10px; vertical-align: middle">
          </td>
        </tr>
      </table>
    </div>
    <!-- Ende Header -->
    {#if image == "proof"}
    <!-- eVn -->
      <div class="column2">
        {#if (!(alreadyDone || evnSent))}
        <img class="floating{tlang}" src="images/infoVvb_{tlang}.png" alt="info" />
          <!-- Versicherungsnachweis -->
          <Evn {rawLead} lang={tlang} bind:sent={evnSent} {redoEvn} {demo}/>
<!--
          {JSON.stringify(rawLead)}
-->          
        {:else}
          {#if lang == "D"}
            <div class="messageleft">
                Dieser Versicherungsnachweis wurde am {dateDisp(rawLead.evnsent)} um {timDisp(rawLead.evnsent)} Uhr an die {rawLead.versicherung} gesandt
            </div>
            <div>&#160;</div> 
            <div>
              Die PDF Bestellung finden Sie hier: 
             <a href="https://lead.car-ware.ch/fop/ngDok?type=nachweis&id={rawLead.id}&guid={rawLead.guid}" target="dok"><img style="height:50px;" src="images/PDFDownload.png" alt="PDF" /></a>
            </div>
            <div>&#160;</div> 
            <div>&#160;</div>
            <div style="padding-bottom: 4px">
              Die versprochene Verarbeitungsdauer beträgt während den Büroöffnungszeiten 4 Stunden.
            </div>
            <div style="padding-bottom: 4px">
              Sollten Sie innerhalb dieser Frist keine Emailbestätigung an {rawLead.user_email} von der Versicherung erhalten
            </div>
            <div style="padding-bottom: 4px">
              raten wir Ihnen sich den Versand des Nachweises an das StVA direkt von der {rawLead.versicherung}
              {#if rawLead.agentur}
              {rawLead.agentur}
              {/if}
              unter {rawLead.evntelefon} bestätigen zu lassen
            </div>
            <div>&#160;</div>
            <div>
              <a href="https://lead.car-ware.ch/pavServer/ngDok?type=vvb&guid={rawLead.guid}" target="dok">
              <img style="height:135px;" src="images/infoVvbPdf_de.png" alt="PDF" />
            </div>
            <div>&#160;</div>
            <div>Wenn Sie diesen erstellten und bereits an die Versicherung gesendeten Versicherungsnachweis für dieses Fahrzeug durch </div>
            <div>einen neuen Versicherungsnachweis ersetzen möchten:</div>
            <div>&#160;</div>
            <div><button on:click="{redo}">Versicherungsnachweis erneut bestellen...</button></div>
          {/if}
          {#if lang == "F"}
            <div class="messageleft">
              Cette attestation d'assurance a été envoyée à la {rawLead.versicherung} le {dateDisp(rawLead.evnsent)} à {timDisp(rawLead.evnsent)}.
            </div>
            <div>&#160;</div> 
            <div>
              Vous trouverez la commande PDF ici :
              <a href="https://lead.car-ware.ch/fop/ngDok?type=nachweis&id={rawLead.id}&guid={rawLead.guid}" target="dok"><img style="height:50px;" src="images/PDFDownload.png" alt="PDF" /></a>
            </div>
            <div>&#160;</div> 
            <div style="padding-bottom: 4px">
                Le délai de traitement promis est de 4 heures pendant les heures d'ouverture des bureaux.
            </div>
            <div style="padding-bottom: 4px">
              Si vous ne recevez pas de confirmation par e-mail à {rawLead.user_email} de la part de l'assurance dans ce délai, 
            </div>
            <div style="padding-bottom: 4px">
              nous vous conseillons de vous faire confirmer l'envoi du justificatif à l'office de la circulation routière directement par la {rawLead.versicherung} au {rawLead.evntelefon} 
            </div>
            <div>&#160;</div>
            <div>
              <a href="https://lead.car-ware.ch/pavServer/ngDok?type=vvb&guid={rawLead.guid}" target="dok">
              <img style="height:125px;" src="images/infoVvbPdf_fr.png" alt="PDF" />
            </div>
            <div>&#160;</div>
            <div>Si vous souhaitez remplacer cette attestation d'assurance créée et déjà envoyée à l'assurance</div>
            <div>pource véhicule par une nouvelle attestation d'assurance:</div>
            <div>&#160;</div>
            <div><button on:click="{redo}">Commander à nouveau une attestation d'assurance...</button></div>
          {/if}
          {#if lang == "I"}
            <div class="messageleft">
              Questo certificato di assicurazione è stato inviato ai {rawLead.versicherung} alle {timDisp(rawLead.evnsent)} del {dateDisp(rawLead.evnsent)}
            </div>
            <div>&#160;</div> 
            <div>
              Potete trovare l'ordine PDF qui: 
              <a href="https://lead.car-ware.ch/pavServer/ngDok?type=vvb&guid={rawLead.guid}" target="dok"><img style="height:50px;" src="images/PDFDownload.png" alt="PDF" /></a>
            </div>
            <div>&#160;</div> 
            <div style="padding-bottom: 4px">
              Il tempo di elaborazione promesso è di 4 ore durante gli orari di apertura degli uffici.
            </div>
            <div style="padding-bottom: 4px">
              Se non ricevete una conferma via e-mail  {rawLead.user_email} dalla compagnia assicurativa all'indirizzo entro questo termine
            </div>
            <div style="padding-bottom: 4px">
              vi consigliamo di farvi confermare la prova all'ufficio della circolazione stradale direttamente dai {rawLead.versicherung} al {rawLead.evntelefon}.
            </div>
            <div>&#160;</div>
            <div>
              <a href="https://lead.car-ware.ch/pavServer/ngDok?type=vvb&guid={rawLead.guid}" target="dok">
              <img style="height:130px;" src="images/infoVvbPdf_it.png" alt="PDF" />
            </div>
            <div>&#160;</div>
            <div>Se desidera sostituire questo certificato di assicurazione per questo veicolo, che è già stato  </div>
            <div>inviato alla compagnia di assicurazione, con un nuovo certificato di assicurazione:</div>
            <div>&#160;</div>
            <div><button on:click="{redo}">Attestato di assicurazione ordinare di nuovo...</button></div>
          {/if}
          {#if rawLead.agent=='BME'}
          <div class="footer">
            <div><img style="width: 450px" src="images/CW Header transparent.png" alt="evn-logo"/></div>
          </div>
          {/if}
        {/if}
      </div>
      <!-- Ende eVn-->
       {/if}
  </div>
</body>

<style>
.evnbody {
  /* Hintergrund */
  --lp-bg-color: #aaabdd; 
  /* Hintergrund header */
  --proof-bg-color: rgb(102, 201, 94); 
  /* Text Header */
  --proof-color: yellow; 
  --input-invalid-bg-color: #06AF8F; 
  --input-invalid-color: #ffffff;
}

.floatinglogo {
  position: absolute;
  left: 1120px;
  top: 120px;
  z-index: 5;
}
 
.floatingit {
  position: absolute;
  left: 720px;
  top: 20px;
  height: 110px;
  z-index: 5;
}
 
.floatingfr {
  position: absolute;
  left: 720px;
  top: 20px;
  height: 120px;
  z-index: 5;
}
 
.floatingde {
  position: absolute;
  left: 750px;
  top: 20px;
  height: 130px;
  z-index: 5;
}
 

  .vvb {
    display: grid;
    grid-template-columns: minmax(200px,700px) 90px;
    grid-column-gap: 0px;
    grid-row-gap: 0px;
  }
  .vvbbg {
    padding: 5px;
    padding-left: 10px;
    background-color: rgb(152, 167, 251);
  }
  .vvbbg1 {
    padding-top: 10px;
  }
  .vvbbg2 {
    padding-bottom: 10px;
  }
  .grid {
    display: grid;
    grid-template-columns: minmax(1000px, auto);
    grid-auto-rows: 110px 180px auto;
    grid-column-gap: 0px;
    grid-row-gap: 0px;
    width: 100vw;
    height: 100vh;
  }
  .gridevn {
    display: grid;
    grid-template-columns: minmax(1000px, auto);
    grid-auto-rows: 110px auto;
    grid-column-gap: 0px;
    grid-row-gap: 0px;
    width: 100vw;
    height: 100vh;
  }
  .grid2 {
    display: grid;
    grid-template-columns: auto auto auto 1fr;
    grid-auto-rows: auto;
    grid-column-gap: 0px;
    grid-row-gap: 0px;
  }

  /* oberer Bereich */
  .column1 {
    background-color: #e7e6e6;
    border-bottom: 0pt solid white;
    padding: 12px;
  }

  /* unterer Bereich */
  .column2 {
    background-color: var(--lp-bg-color);
    padding: 12px;
  }


  .row1 {
    background-color: rgb(114, 59, 49);
    padding: 3px;
  }

  .offer {
    background-color: rgb(255, 217, 102);
    vertical-align: middle;
  }
  .compare {
    background-color: rgb(105, 170, 214);
  }
  .proof {
/*    background-color: rgb(145, 145, 145); */
    background-color: var(--proof-bg-color);
    color: var(--proof-color);
  }

  .info {
    width: 1200px;
  }

  .cwlogo {
    height: 90px;
    margin-top: -70px;
    margin-left: 150px;
  }

  .grey {
    background-color: #c4c4c4;
    color: #4c4c4c;
    font-weight: normal
  }
  .normal {
    font-weight: normal
  }

  .big {
    font-size: 12pt;
  }

  .locker {
    font-size: 13pt;
    padding-top: 3pt;
    padding-bottom: 3pt;
  }
  .lockerer {
    font-size: 18pt;
    padding-top: 3pt;
    padding-bottom: 3pt;
  }
  .footer {
    padding-top: 30px;
  }
</style>
