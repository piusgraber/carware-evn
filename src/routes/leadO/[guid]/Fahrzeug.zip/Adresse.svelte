<script>
    export let adresse = {};
    export let title;
    export let adrValid = false;
    export let plzValid = true;
    export let lang='it';

    import { texte } from "./helpers/texte.js";

    $: anreden = [
        { id: "", value: "--" },
        { id: 1, value: texte.herr[lang] },
        { id: 2, value: texte.frau[lang] },
        { id: 3, value: texte.firma[lang] },
    ];


    const checkFormsValid = (rec) => {
        let isValid = true;
        if (adresse) {
            isValid = isValid && adresse.anredeid;
            isValid = isValid && adresse.name;
            isValid = isValid && adresse.adresse;
            isValid = isValid && adresse.plz.length >= 4;
            isValid = isValid && adresse.ort;
            isValid = isValid && !invalidLen(adresse.name, 5)
        }
        return isValid;
    };
    $: {
        adrValid = checkFormsValid(adresse);
    }

$: invalidPlz = !adresse || !adresse.plz || adresse.plz.length < 4

const  invalidLen = (fld, len) => !fld || fld.length < len

</script>


<!--
    {JSON.stringify(adresse)}
{adrValid}x{plzValid}:{invalidPlz}
-->
<div class="gridevn2">
    <div>{title}</div>
    <div></div>
    <div>{texte.anrede[lang]}</div>
    <div>            <select bind:value={adresse.anredeid} required="true">
        {#each anreden as art}
            <option value={art.id}>{art.value}</option>
        {/each}
    </select>
    </div>
    <div>{texte.name[lang]}</div>
    <div>
        <input    class:invalid={invalidLen(adresse.name, 5)} class="adresse"  bind:value={adresse.name}  required="true"/>
    </div>
    <div>{texte.adresse[lang]}</div>
    <div>
        <input     class:invalid={invalidLen(adresse.adresse, 4)} class="adresse" bind:value={adresse.adresse}  required="true"/>
    </div>
    <div>{texte.plzort[lang]}</div>
    <div>
        <input class:invalid={invalidPlz || !plzValid}
        class="plz" bind:value={adresse.plz}  required="true"/>      
        <input bind:value={adresse.ort}  required="true"/>
    </div>
</div>
<!--
{JSON.stringify(adresse)}
-->
<style>


select:invalid, input:invalid,   input.invalid  {
    background-color: var(--input-invalid-bg-color);
    color: var(--input-invalid-color);
    border: 1pt solid rgb(99, 99, 99);
  }


      .gridevn2 {
    display: grid;
    grid-template-columns: 220px 320px;
    grid-auto-rows: auto;
    grid-column-gap: 0px;
    grid-row-gap: 0px;
  }
  .plz {
    width: 60px;
}
.adresse {
    width: 260px;
}

</style>
